socket.emit
$('#button').click(function(){
  socket.emit('butt_click')
})
var count = 0
// -----------------//

socket.on('add_count',function(data){

}

}).

socket.on('butt_click',function(){

  count++;

  io.emit('add_count', {response: count})

})
