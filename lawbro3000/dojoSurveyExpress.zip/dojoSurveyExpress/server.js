var express = require("express");
var path = require("path");
var app = express();
var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: true }));
// static content
app.use(express.static(path.join(__dirname, "./static")));
// setting up ejs and our views folder
app.set('views', path.join(__dirname, './views'));

app.set('view engine', 'ejs');
// root route to render the index.ejs view
app.get('/', function(req, res) {
 res.render("index");
})
// post route to show info on page
  app.post('/results', function(req, res) {
 		submitted_info = {
 			name: req.body.name,
 			dojo_location: req.body.dojo_location,
 			favorite_language: req.body.favorite_language,
 			comment: req.body.comment
 		};
 	 	res.render("results",{user_data: submitted_info});
 	})
// tell the express app to listen on port 8000
app.listen(8000, function() {
 console.log("listening on port 8000");
});
