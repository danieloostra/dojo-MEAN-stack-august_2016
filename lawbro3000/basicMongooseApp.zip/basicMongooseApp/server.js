var mongoose = require('mongoose');

var express = require('express');
var app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));
var path = require('path');


mongoose.connect('mongodb://localhost/basic_mongoose');
var UserSchema = new mongoose.Schema({
 name: String,
 age: Number
})
mongoose.model('User', UserSchema); 
var User = mongoose.model('User'); 


app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
app.get('/', function(req, res) {
User.find({}, function(err, users) {   
console.log(users)
})
    res.render('index');
})
app.post('/users', function(req, res) {

  var user = new User({name: req.body.name, age: req.body.age});
    user.save(function(err) {
      if (err) {
        console.log('Error');
      } 
      else{
        console.log('success'); 
        res.redirect('/');
      }

    })
      console.log(req.body.name);
      console.log(req.body.age);
  })
// Setting our Server to Listen on Port: 8000
app.listen(8000, function() {
    console.log("listening on port 8000");
})


