console.log('Server->Models->friends.js');
var mongoose = require('mongoose');
// build your friend schema and add it to the mongoose.models
var friendSchema = new mongoose.Schema({
   fname: String, 
   lname: String,
     dob: Date,
     
});
console.log ("inside friends Model"); 
var friendModel = mongoose.model('friendModel',friendSchema)