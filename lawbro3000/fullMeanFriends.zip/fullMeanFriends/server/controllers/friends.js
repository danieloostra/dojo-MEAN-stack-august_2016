console.log('Server->Controllers->friends controller->friends.js');

var mongoose = require('mongoose');
var friend = mongoose.model('friendModel');

function FriendsController() {
    this.index = function(req, res) {

        friend.find({}, function(err, friends) {
            res.json(friends);
        })
    };
    this.create = function(req, res) {
        console.log('This inside of the Friends Controller Create methode');
        var newFriend = new friend({
            fname: req.body.fname,
            lname: req.body.lname,
            dob: req.body.dob
        });
        newFriend.save(function(err) {
            if (err) {
                console.log('something went wrong');
            } else {
                console.log('Added to the DATABASE');
                res.json(newFriend);
            }
        });
    };
    this.show = function(req, res) {
        console.log('This inside of the Friends Controller Create method');
        friend.findOne({
            _id: req.params.id
        }, function(err, friend) {
            res.json(friend)
        })
    };
    this.edit = function(req, res) {
        friend.findOne({
            _id: req.params.id
        }, function(err, editFriend) {
            editFriend.fname = req.body.fname;
            editFriend.lname = req.body.lname;
            editFriend.dob = req.body.dob;

            editFriend.save(function(err) {
                if (err) {
                    console.log('something went wrong')
                } else {
                    console.log('Added to the DATABASE')
                    res.json(editFriend)
                }
            })
        })
    }
    this.delete = function(req, res) {
        console.log("Enter the Delete section of Server-Freinds.js")
        friend.remove({
            _id: req.params.id
        }, function(err, deleteFriend) {

            if (err) {
                console.log('something went wrong')

            } else {
                console.log('Deleted frome the DATABASE')
                res.send();
            }
        })
    }
};

module.exports = new FriendsController();