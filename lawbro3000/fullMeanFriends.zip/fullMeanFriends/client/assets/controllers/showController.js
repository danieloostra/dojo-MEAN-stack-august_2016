app.controller('showController',  ['$scope','$routeParams','friendsFactory','$location',  function($scope,$routeParams, friendsFactory,$location) {


console.log("Inside the show Controller")
$scope.friend={}


$scope.show = function(){
  friendsFactory.show($routeParams.id, function(returnedData){
   $scope.friend = returnedData;
   console.log(returnedData)
  

  });
}
$scope.show()





/*
  OUR $scope.create function goes here <-- $scope because we need to access this method 
  with ng-subm  it or ng-click (from the form in the previous assignment).  
  Want to all of the friends when we get back?  We can re-run index.
*/
}]);

