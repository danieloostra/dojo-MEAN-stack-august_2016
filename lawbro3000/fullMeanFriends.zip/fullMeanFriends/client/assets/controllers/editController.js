app.controller('editController',  ['$scope','friendsFactory','$location', '$routeParams', function($scope, friendsFactory,$location,$routeParams) {
/*
  THIS INDEX METHOD ACCESSES THE FRIENDS FACTORY AND RUNS THE FRIENDS INDEX.
  WE MIGHT RE USE INDEX A FEW TIMES, SO TO MINIMIZE REPETITION WE SET IT AS A VARIABLE.
*/

$scope.friend = {};

console.log($scope.friend)

var index = function(){
friendsFactory.show($routeParams.id, function(returnedData){
   var date = new Date(returnedData.dob)
   date.toLocaleDateString('en-US')
   returnedData.dob = date

   $scope.friend = returnedData;
   console.log(returnedData)

 });
 };
index();

$scope.edit = function(){
   friendsFactory.edit($scope.friend, function(){
  $location.url('/')


  });

};

/*
  OUR $scope.create function goes here <-- $scope because we need to access this method 
  with ng-subm  it or ng-click (from the form in the previous assignment).  
  Want to all of the friends when we get back?  We can re-run index.
*/
}]);