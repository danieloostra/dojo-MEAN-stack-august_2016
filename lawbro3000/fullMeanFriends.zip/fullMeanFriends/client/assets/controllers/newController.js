 
app.controller('newController',  ['$scope','friendsFactory','$location',  function($scope, friendsFactory,$location) {
/*
  THIS INDEX METHOD ACCESSES THE FRIENDS FACTORY AND RUNS THE FRIENDS INDEX.
  WE MIGHT RE USE INDEX A FEW TIMES, SO TO MINIMIZE REPETITION WE SET IT AS A VARIABLE.
*/

$scope.friends = {};
$scope.friend = {};

console.log($scope.friend)

var index = function(){
friendsFactory.index(function(returnedData){
$scope.friends = returnedData;
console.log($scope.friends);
 });
 };
index();

$scope.create = function(){
  friendsFactory.create($scope.friend, function(){
   console.log("Before create function");
   $location.url('/')
   console.log("After create function");
  });
};

$scope.Remove_friend = function(id){
  console.log('in the DeleteController');
  friendsFactory.delete(id, function(data){
  index();
  $location.url('/')

  });

};
/*
  OUR $scope.create function goes here <-- $scope because we need to access this method 
  with ng-subm  it or ng-click (from the form in the previous assignment).  
  Want to all of the friends when we get back?  We can re-run index.
*/
}]);